/*
  # Set Admin Permissions and Enterprise Access
  
  1. Changes
    - Ensure unique constraints exist
    - Set up admin permissions
    - Create Enterprise subscription
*/

-- First ensure unique constraints exist
ALTER TABLE admin_settings DROP CONSTRAINT IF EXISTS admin_settings_user_id_key;
ALTER TABLE admin_settings ADD CONSTRAINT admin_settings_user_id_key UNIQUE (user_id);

ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_user_id_key;
ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_user_id_key UNIQUE (user_id);

-- Create function to safely set up admin access
CREATE OR REPLACE FUNCTION setup_admin_access(admin_email text)
RETURNS void AS $$
DECLARE
  v_user_id uuid;
  v_plan_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id 
  FROM auth.users 
  WHERE email = admin_email;

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User with email % not found', admin_email;
  END IF;

  -- Get Enterprise plan ID
  SELECT id INTO v_plan_id 
  FROM subscription_plans 
  WHERE name = 'Enterprise';

  IF v_plan_id IS NULL THEN
    RAISE EXCEPTION 'Enterprise plan not found';
  END IF;

  -- Set admin permissions
  INSERT INTO admin_settings (
    user_id,
    is_admin,
    admin_access_level
  ) VALUES (
    v_user_id,
    true,
    'full'
  )
  ON CONFLICT (user_id) 
  DO UPDATE SET
    is_admin = true,
    admin_access_level = 'full',
    updated_at = now();

  -- Set up Enterprise subscription
  INSERT INTO subscriptions (
    user_id,
    plan_id,
    status,
    current_period_start,
    current_period_end,
    cancel_at_period_end,
    stripe_subscription_id,
    stripe_customer_id
  ) VALUES (
    v_user_id,
    v_plan_id,
    'active',
    now(),
    now() + interval '100 years',
    false,
    'admin_subscription',
    'admin_customer'
  )
  ON CONFLICT (user_id) 
  DO UPDATE SET
    plan_id = v_plan_id,
    status = 'active',
    current_period_end = now() + interval '100 years',
    updated_at = now();

END;
$$ LANGUAGE plpgsql;

-- Set up admin access
SELECT setup_admin_access('maniksharmawork@gmail.com');

-- Clean up
DROP FUNCTION IF EXISTS setup_admin_access(text);