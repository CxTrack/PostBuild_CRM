/*
  # Set up Enterprise plan and admin access
  
  1. Changes
    - Ensures Enterprise plan exists
    - Sets up admin user with proper permissions
    - Creates admin subscription
    
  2. Security
    - Uses proper unique constraints
    - Handles potential errors gracefully
*/

-- First ensure we have the Enterprise plan
INSERT INTO subscription_plans (
  name, 
  description, 
  price, 
  interval, 
  features, 
  is_active,
  stripe_price_id
) 
SELECT 
  'Enterprise',
  'Complete solution for established businesses',
  399.99,
  'month',
  jsonb_build_array(
    'All Business Plan features',
    'AI-Powered Virtual Assistant',
    'Automated Voice Collection Calls',
    'Smart Payment Reminders',
    'AI Customer Sentiment Analysis',
    'Voice-to-Text Transcription',
    'Predictive Payment Analysis',
    'Natural Language Processing',
    'Automated Follow-up System',
    'AI Revenue Forecasting',
    'Smart Customer Segmentation',
    'Voice Authentication',
    'Multi-Language Support',
    'Custom AI Training',
    'Unlimited Team Members',
    'Advanced Analytics Dashboard',
    'Custom Integration Support',
    'Priority 24/7 Support',
    'Dedicated Account Manager'
  ),
  true,
  'price_1QypERGmarpEtABMXeIyF1Dq'
WHERE NOT EXISTS (
  SELECT 1 FROM subscription_plans WHERE name = 'Enterprise'
);

-- Get the Enterprise plan ID
DO $$ 
DECLARE
  admin_user_id uuid;
  enterprise_plan_id uuid;
BEGIN
  -- Get the admin user ID
  SELECT id INTO admin_user_id 
  FROM auth.users 
  WHERE email = 'maniksharmawork@gmail.com';

  IF admin_user_id IS NULL THEN
    RAISE EXCEPTION 'Admin user not found';
  END IF;

  -- Get Enterprise plan ID
  SELECT id INTO enterprise_plan_id 
  FROM subscription_plans 
  WHERE name = 'Enterprise';

  IF enterprise_plan_id IS NULL THEN
    RAISE EXCEPTION 'Enterprise plan not found';
  END IF;

  -- Set admin permissions if not already set
  INSERT INTO admin_settings (
    id,
    user_id,
    is_admin,
    admin_access_level,
    created_at,
    updated_at
  ) VALUES (
    gen_random_uuid(),
    admin_user_id,
    true,
    'full',
    now(),
    now()
  )
  ON CONFLICT DO NOTHING;

  -- Set up Enterprise subscription if not exists
  INSERT INTO subscriptions (
    id,
    user_id,
    plan_id,
    status,
    current_period_start,
    current_period_end,
    cancel_at_period_end,
    stripe_subscription_id,
    stripe_customer_id,
    created_at,
    updated_at
  ) VALUES (
    gen_random_uuid(),
    admin_user_id,
    enterprise_plan_id,
    'active',
    now(),
    now() + interval '100 years',
    false,
    'admin_subscription',
    'admin_customer',
    now(),
    now()
  )
  ON CONFLICT DO NOTHING;

END $$;