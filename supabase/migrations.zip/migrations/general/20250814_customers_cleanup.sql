ALTER TABLE customers
DROP COLUMN pipeline_stage,
DROP COLUMN opportunity_close_date,
DROP COLUMN opportunity_probability,
DROP COLUMN opportunity_value;